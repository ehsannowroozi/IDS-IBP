import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from sklearn.utils.class_weight import compute_class_weight
from sklearn.preprocessing import StandardScaler


# Function to load the dataset
def load_dataset(file_path):
    df = pd.read_csv(file_path)
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values
    return X, y


# Modified Neural network model with specified hidden layers
class ComplexNN(nn.Module):
    def __init__(self, input_size, hidden_units_list, dropout_prob=0.5):
        super(ComplexNN, self).__init__()
        self.layers = nn.ModuleList()

        # Setting up the first hidden layer
        self.layers.append(nn.Linear(input_size, hidden_units_list[0]))
        self.layers.append(nn.Tanh())  # Changed activation function to Tanh
        self.layers.append(nn.Dropout(p=dropout_prob))

        # Setting up subsequent hidden layers
        for i in range(1, len(hidden_units_list)):
            self.layers.append(nn.Linear(hidden_units_list[i - 1], hidden_units_list[i]))
            self.layers.append(nn.Tanh())  # Changed activation function to Tanh
            self.layers.append(nn.Dropout(p=dropout_prob))

        # Output layer
        self.layers.append(nn.Linear(hidden_units_list[-1], 2))

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

# Function to calculate class weights
def calculate_class_weights(labels):
    class_weights = compute_class_weight('balanced', classes=np.unique(labels), y=labels)
    return torch.tensor(class_weights, dtype=torch.float)

# Compute IBP bounds for a layer
def compute_ibp_bounds(layer, lb, ub):
    if isinstance(layer, nn.Linear):
        W = layer.weight.data.float()  # Convert weights to float
        b = layer.bias.data.float()  # Convert biases to float
        lb = lb.float()  # Convert lower bounds to float
        ub = ub.float()  # Convert upper bounds to float
        lb_new = torch.mm(lb, torch.where(W > 0, W, torch.zeros_like(W)).t()) + \
                 torch.mm(ub, torch.where(W < 0, W, torch.zeros_like(W)).t()) + b
        ub_new = torch.mm(ub, torch.where(W > 0, W, torch.zeros_like(W)).t()) + \
                 torch.mm(lb, torch.where(W < 0, W, torch.zeros_like(W)).t()) + b
    elif isinstance(layer, nn.Tanh):
        lb_new, ub_new = lb, ub
    else:
        lb_new = torch.clamp(lb, min=0)
        ub_new = torch.clamp(ub, min=0)
    return lb_new, ub_new



# Training function
def train(model, criterion, optimizer, data_loader, device):
    model.train()
    for inputs, labels in data_loader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

# Evaluation function
def evaluate(model, data_loader, device):
    model.eval()
    all_predictions = []
    all_labels = []
    with torch.no_grad():
        for inputs, labels in data_loader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs = model(inputs)
            _, predicted = torch.max(outputs, 1)
            all_predictions.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    accuracy = accuracy_score(all_labels, all_predictions)
    precision = precision_score(all_labels, all_predictions, average='weighted', zero_division=0)
    recall = recall_score(all_labels, all_predictions, average='weighted', zero_division=0)
    f1 = f1_score(all_labels, all_predictions, average='weighted', zero_division=0)
    return accuracy, precision, recall, f1

# Function to propagate bounds through the model and display them numerically for the last layer
def propagate_bounds_and_display_last_layer(model, x_lb, x_ub, device):
    for layer in model.layers:
        x_lb, x_ub = compute_ibp_bounds(layer, x_lb, x_ub)

    # Display logic for numeric values of the last layer (two classes)
    # lb_np = x_lb.cpu().detach().numpy()
    # ub_np = x_ub.cpu().detach().numpy()

    # Print lower and upper bounds for each class (assuming binary classification)
    # for i in range(2):
    #     print(f"Class {i} - Lower Bound = {lb_np[0][i]}, Upper Bound = {ub_np[0][i]}")

# Compute certified accuracy with numeric display for the last layer
def compute_certified_accuracy_with_display_last_layer(model, loader, epsilon, device):
    correct_certified = 0
    total = 0
    model.eval()
    with torch.no_grad():
        for data, target in loader:
            data, target = data.to(device), target.to(device)
            lb, ub = data - epsilon, data + epsilon

            # Initialize bounds for the first layer
            lb_layer, ub_layer = lb, ub

            for layer in model.layers:
                lb_layer, ub_layer = compute_ibp_bounds(layer, lb_layer, ub_layer)

            # Display numeric values for the last layer (two classes)
            # lb_np = lb_layer.cpu().detach().numpy()
            # ub_np = ub_layer.cpu().detach().numpy()

            # Print lower and upper bounds for each class (assuming binary classification)
            # for i in range(2):
            #     print(f"Class {i} - Lower Bound = {lb_np[0][i]}, Upper Bound = {ub_np[0][i]}")

            # Determine if the prediction is certified
            _, pred_lb = torch.max(lb_layer, 1)
            _, pred_ub = torch.max(ub_layer, 1)
            certified = (pred_lb == pred_ub) & (pred_lb == target)
            correct_certified += certified.sum().item()
            total += target.size(0)

    certified_accuracy = correct_certified / total
    return certified_accuracy

if __name__ == "__main__":
    # File path to dataset
    file_path = '~/Desktop/IEEE_CSR/CIC.csv'  # Update this with your dataset path

    # Load dataset
    X, y = load_dataset(file_path)

    # Calculate class weights
    class_weights = calculate_class_weights(y)

    # Split the data into train, validation, and test sets
    X_train, X_combined, y_train, y_combined = train_test_split(X, y, test_size=0.4, random_state=42, stratify=y)
    X_val, X_test, y_val, y_test = train_test_split(X_combined, y_combined, test_size=0.5, random_state=42, stratify=y_combined)

    # Standardize features
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_val = scaler.transform(X_val)
    X_test = scaler.transform(X_test)

    # Initialize the model, criterion, and optimizer AFTER defining X_train
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    hidden_units_list = [512, 256, 128, 64, 8]  # Define the structure of hidden layers
    dropout_prob = 0.5  # Specify dropout probability

    # Correctly instantiate the model using hidden_units_list
    model = ComplexNN(X_train.shape[1], hidden_units_list, dropout_prob).to(device)

    criterion = nn.CrossEntropyLoss(weight=class_weights.to(device))
    optimizer = optim.Adam(model.parameters(), lr=1e-4)

    # Create PyTorch data loaders for train, validation, and test sets
    train_dataset = TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train))  # Use torch.LongTensor() for labels
    val_dataset = TensorDataset(torch.FloatTensor(X_val), torch.LongTensor(y_val))  # Use torch.LongTensor() for labels
    test_dataset = TensorDataset(torch.FloatTensor(X_test), torch.LongTensor(y_test))  # Use torch.LongTensor() for labels

    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

    # Create a list to store results
    results = []

    # Training loop
    for epoch in range(40):  # Adjust epochs as needed
        train(model, criterion, optimizer, train_loader, device)
        train_accuracy, _, _, _ = evaluate(model, train_loader, device)
        val_accuracy, val_precision, val_recall, val_f1 = evaluate(model, val_loader, device)
        test_accuracy, precision, recall, f1 = evaluate(model, test_loader, device)
        results.append(f"Epoch {epoch + 1}: Train Accuracy = {train_accuracy}, Validation Accuracy = {val_accuracy}, "
                       f"Test Accuracy = {test_accuracy}, Precision = {precision}, Recall = {recall}, F1 = {f1}")
        print(f"Epoch {epoch + 1}: Train Accuracy = {train_accuracy}, Validation Accuracy = {val_accuracy}, "
                       f"Test Accuracy = {test_accuracy}, Precision = {precision}, Recall = {recall}, F1 = {f1}")

    # Save the entire model
    model_save_path = 'model_complete.pth'
    torch.save(model, model_save_path)
    print(f"Model saved to {model_save_path}")

    # Print training accuracy
    print(f"Training Accuracy (before attack): {train_accuracy}")

    # Compute and display certified accuracy numerically for the last layer with epsilon values
    epsilon_values = [0.00001, 0.0001, 0.001, 0.01, 0.1, 0.9]
    for epsilon in epsilon_values:
        certified_accuracy = compute_certified_accuracy_with_display_last_layer(model, test_loader, epsilon, device)
        results.append(f"Certified Accuracy (epsilon = {epsilon}): {certified_accuracy}")
        print(f"Certified Accuracy (epsilon = {epsilon}): {certified_accuracy}")

    # Store results in a text file
    with open("results.txt", "w") as f:
        for line in results:
            f.write(line + "\n")

    print("Results saved to results.txt")


#Ehsan Comment

#In summary, the choice of epsilon determines how much uncertainty is allowed
#around each data point. Very small epsilon values result in high certified accuracy
#because they provide a very narrow margin for classification. As epsilon increases,
#the margin widens, but it can lead to overlap with decision boundaries, reducing certified accuracy.
#The selection of epsilon depends on the specific application and trade-offs between robustness and
#accuracy.

